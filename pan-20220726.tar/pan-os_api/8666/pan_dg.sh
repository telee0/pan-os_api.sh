wget --tries=2 --timeout=5 --post-file=xml/pan_dg.xml --no-check-certificate --output-document=logs/pan_dg.log.xml --append-output=logs/pan_dg.log "https://192.168.1.245/api"
